<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

//rutas de inicio
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/homeAdmin', 'HomeAdminController@index')->name('homeAdmin');

//Login
Route::get('auth/google', 'Auth\LoginController@redirectToGoogle');
Route::get('auth/google/callback', 'Auth\LoginController@handleGoogleCallback');

//LogOut
Route::get('logout', 'Auth\LoginController@logout')->name('logout');


//Profesor
Route::get('crearIncidencia','incidenciaController@CrearIncidencia')->name('crearIncidencia');
Route::get('consultarIncidenciasProfesor','incidenciaController@ConsultarIncidenciasProfesor')->name('consultarIncidenciasProfesor');
Route::post('modificarIncidenciaProfesor','incidenciaController@ModificarIncidenciasProfesor')->name('modificarIncidenciaProfesor');


//Administrador
Route::get('crearIncidenciaAdmin','incidenciaController@CrearIncidencia')->name('crearIncidenciaAdmin');
Route::get('consultarIncidenciasAdmin','incidenciaController@ConsultarIncidenciasAdmin')->name('consultarIncidenciasAdmin');
Route::post('modificarIncidenciaAdmin','incidenciaController@ModificarIncidenciaAdmin')->name('modificarIncidenciaAdmin');
Route::get('borrarIncidencia','incidenciaController@BorrarIncidencia')->name('borrarIncidencia');


//Ambos
//Ruta de guardar incidencia
Route::post('guardarDatos','incidenciaController@GuardarDatos')->name('guardarDatos');