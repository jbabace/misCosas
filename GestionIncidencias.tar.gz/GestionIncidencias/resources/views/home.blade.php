@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><label style="font-size:40px">Bienvenido</label><a class="btn btn-info btn-lg btn-block" style="float:right; width: 100px" href="{{ route('crearIncidencia') }}">Crear </a></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>Fecha</th>
                            <th>Código</th>
                            <th>Aula</th>
                            <th>Equipo</th>
                            <th>Descripción</th>
                            <th>Estado</th>
                          </tr>
                        </thead>
                        <tbody>
                            @foreach ($incidencias as $incidencia)
                            <tr>
                                <td>{{ $incidencia -> created_at }}</td>
                                <td>{{ $incidencia -> codigo }}</td>
                                <td>{{ $incidencia -> aula }}</td>
                                <td>{{ $incidencia -> equipo }}</td>
                                <td>{{ $incidencia -> descripcion }}</td>
                                <td>{{ $incidencia -> estado }}</td>
                                <td><a class="btn btn-lg btn-block" href="{{ route('consultarIncidenciasProfesor', ['id'=>$incidencia->id]) }}">Detalles </a></td>
                            </tr>
                            @endforeach
                        </tbody>
                      </table>                 
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
