<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncidenciasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Incidencia', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('aula');
            $table->string('codigo');
            $table->string('equipo');
            $table->string('descripcion');
            $table->string('estado');
            $table->string('mas_info')->default(""); //comentarios
            $table->string('comentarios_admin')->default(""); //comentarios
            $table->unsignedBigInteger('profesorID');
            $table->foreign('profesorID')
                    ->references('id')-> on('Profesor')
                    ->onUpdate('cascade')
                    ->onDelete('cascade')
            ;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Incidencia');
    }
}
