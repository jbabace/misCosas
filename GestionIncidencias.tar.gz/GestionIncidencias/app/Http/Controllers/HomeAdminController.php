<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Incidencia as incidencia;
use App\Profesor;
use DB;

class HomeAdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
		$incidencias = DB::select('Select * from Incidencia order by Id desc');

        return view('homeAdmin', ['incidencias' => $incidencias]);
    }
}
