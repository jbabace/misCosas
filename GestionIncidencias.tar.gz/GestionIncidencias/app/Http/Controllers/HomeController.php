<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Incidencia as incidencia;
use App\Profesor;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $profesorID = Auth::user()->id; //tabla profesor
		$incidencias = DB::select('Select * from Incidencia where profesorID = "'.$profesorID.'" order by Id desc');

        return view('home', ['incidencias' => $incidencias]);
    }
}
