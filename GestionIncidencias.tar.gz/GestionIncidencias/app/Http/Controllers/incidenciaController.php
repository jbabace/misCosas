<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\Incidencia as incidencia;
use App\Profesor;
use DB;
use Mail;

class incidenciaController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }

    public function inicio(){
        return view('home');
    }

    public function CrearIncidencia(){
      if(auth()->user()->admin == 1){
        return view('crearIncidenciaAdmin');
      }else{
        return view('crearIncidencia');
      } 
    }

    public function GuardarDatos(Request $request){
        //Creamos una variable para comprobar las validaciones
        $validaciones = array(
            'profesorID'=>'required',
            'aula'=>'required',
            'equipo'=>'required',
            'codigo'=>'required',
            'descripcion'=>'required',
            'estado'=>'required',
        );
        //Guardamos las validaciones
        $validacion = Validator::make($request->all(),$validaciones);

        if ($validacion->fails()){
          if(auth()->user()->admin == 1){
            return redirect('crearIncidenciaAdmin')
            ->withErrors($validacion)
            ->withInput();
          }else{
            return redirect('crearIncidencia')
            ->withErrors($validacion)
            ->withInput();
          }

        }else{
            $datos = new Incidencia;
            $datos -> profesorID = $request->input('profesorID');
            $datos -> aula = $request->input('aula');
            $datos -> equipo = $request->input('equipo');
            $datos -> codigo = $request->input('codigo');
            $datos -> descripcion = $request->input('descripcion');
            $datos -> estado = $request->input('estado');

            $datos -> save();
            
            /*
            $admin=Profesor::where('admin','1')->first();

            Mail::send('vistaMailAdmin', ['request' => $request], function (Message $mensaje) use ($admin){
            $mensaje->to( $admin->email, 'Administrador')->subject('Reporte de incidencia');
            });*/

            if(auth()->user()->admin == 1){
              $incidencias = DB::select('Select * from Incidencia order by Id desc');

              return view('homeAdmin', ['incidencias' => $incidencias]);
              
            }else{
              $profesorID = Auth::user()->id; //tabla profesor
		          $incidencias = DB::select('Select * from Incidencia where profesorID = "'.$profesorID.'" order by Id desc');

              return view('home', ['incidencias' => $incidencias]);
            }
        }
    }

    public function ConsultarIncidenciasProfesor(Request $request){
      $id=(int)$request->input('id');
      $idProfesor = Auth::user()->id;
      $incidencia = DB::select('Select * from Incidencia where profesorID = "'.$idProfesor.'" and id = "'.$id.'"  ');
      return view('consultarIncidenciasProfesor', ['incidencia' => $incidencia]);
    }


    public function ModificarIncidenciasProfesor (Request $request){

      if ($request->aula!="")
           $update=DB::table('Incidencia')->where('id', '=', $request->id)
     ->update(['aula' => $request->aula]);

     if ($request->equipo!="")
          $update=DB::table('Incidencia')->where('id', '=',$request->id)
    ->update(['equipo' => $request->equipo]);

    if ($request->estado!="")
         $update=DB::table('Incidencia')->where('id', '=', $request->id)
    ->update(['estado' => $request->estado]);


      if ($request->codigo!="")
           $update=DB::table('Incidencia')->where('id', '=', $request->id)
     ->update(['codigo' => $request->codigo]);

     if ($request->mas_info!="")
          $update=DB::table('Incidencia')->where('id', '=', $request->id)
    ->update(['mas_info' => $request->mas_info]);

    return redirect('home');

    }


    public function ConsultarIncidenciasAdmin(Request $request){
      $id=(int)$request->input('id');
      $incidencia = DB::select('Select * from Incidencia where id = "'.$id.'"  ');
      return view('consultarIncidenciasAdmin', ['incidencia' => $incidencia]);
    }
  
      public function modificarIncidenciaAdmin (Request $request){
  
        if ($request->aula!="")
              $update=DB::table('Incidencia')->where('id', '=', $request->id)
        ->update(['aula' => $request->aula]);
  
        if ($request->equipo!="")
             $update=DB::table('Incidencia')->where('id', '=',$request->id)
       ->update(['equipo' => $request->equipo]);
  
       if ($request->estado!="")
            $update=DB::table('Incidencia')->where('id', '=', $request->id)
       ->update(['estado' => $request->estado]);
  
       if ($request->codigo!="")
            $update=DB::table('Incidencia')->where('id', '=', $request->id)
        ->update(['codigo' => $request->codigo]);
  
        if ($request->descripcion!="")
             $update=DB::table('Incidencia')->where('id', '=', $request->id)
        ->update(['descripcion' => $request->descripcion]);
  
        if ($request->mas_info!="")
             $update=DB::table('Incidencia')->where('id', '=', $request->id)
        ->update(['mas_info' => $request->mas_info]);
  
       if ($request->comentarios_admin!="")
            $update=DB::table('Incidencia')->where('id', '=', $request->id)
        ->update(['comentarios_admin' => $request->comentarios_admin]);
  
        return redirect('homeAdmin');
  
      }

      public function BorrarIncidencia(Request $request){
        $id=(int)$request->input('id');
        DB::table('Incidencia')->where('id', '=', $id)->delete();
        $incidencias = DB::select('Select * from Incidencia order by Id desc');
        return view('homeAdmin', ['incidencias' => $incidencias]);

      }
  
}
