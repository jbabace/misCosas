<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Incidencia extends Model
{
    //
    protected $table = 'Incidencia';
    protected $fillable = ['aula', 'fecha', 'codigo', 'equipo', 'descripcion', 'estado', 
    'mas_info', 'comentarios_admin', 'profesorID'];
}
