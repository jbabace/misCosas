<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;


class Profesor extends Authenticatable
{
    //
    protected $table = 'Profesor';
    protected $fillable = ['id', 'name', 'google_id', 'email', 'avatar', 'avatar_original'];

    protected $hidden = ['password', 'remember_token'];
}
