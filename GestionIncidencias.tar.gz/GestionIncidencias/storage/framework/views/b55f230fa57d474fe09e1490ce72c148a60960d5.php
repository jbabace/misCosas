<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Ver Incidencias Profesor</div>
                <div class="col-md-2 col-md-offset-10">
                    <a class="btn "  href="<?php echo e(route('home')); ?>"><strong>Volver</strong></a>
                </div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
										<table class="table table-striped">
									    <thead>
									      <tr>
									        <th>Fecha</th>
									        <th>Código</th>
									        <th>Aula</th>
													<th>Equipo</th>
													<th>Descripción</th>
													<th>Estado</th>
									      </tr>
									    </thead>
									    <tbody>
												<?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									      <tr>
									        <td><?php echo e($incidencia -> created_at); ?></td>
									        <td><?php echo e($incidencia -> codigo); ?></td>
													<td><?php echo e($incidencia -> aula); ?></td>
													<td><?php echo e($incidencia -> equipo); ?></td>
													<td><?php echo e($incidencia -> descripcion); ?></td>
													<td><?php echo e($incidencia -> estado); ?></td>
                          <td><a class="btn btn-lg btn-block" href="<?php echo e(route('consultarIncidenciasProfesor', ['id'=>$incidencia->id])); ?>">Detalles </a></td>

									      </tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									    </tbody>
									  </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/babace/Escritorio/GestionIncidencias/resources/views/verIncidenciaProfesor.blade.php ENDPATH**/ ?>