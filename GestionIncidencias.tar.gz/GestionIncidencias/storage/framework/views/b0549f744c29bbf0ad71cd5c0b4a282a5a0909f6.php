<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
              <?php $__currentLoopData = $incidencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-heading">Incidencia Nº <?php echo e($incidencia -> id); ?></div>
                <div class="col-md-2 col-md-offset-10">
                    <a class="btn "  href="<?php echo e(route('verIncidenciaProfesor')); ?>"><strong>Volver</strong></a>
                </div>
                <div class="panel-body">
									<form class="form-horizontal" method="post" action="<?php echo e(route('modificarDatosIncidenciaProfesor')); ?>">
										<?php echo e(csrf_field()); ?>

									<div class="container">
									<div class="row">
                    <div class="col-md-6 col-md-offset-1">
                      <input type="hidden" class="form-control" name="id" value="<?php echo e($incidencia -> id); ?>" >
											<div class=" col-md-3">
												<label class="control-label" for="profesorID">ID Profesor:</label>
												</br>
											</div>
											<div class=" col-md-7">
                                            <input type="text" class="form-control" id="profesorID" name="profesorID" value="<?php echo e(Auth::user()->id); ?>" readonly="readonly">
												</br>
											</div>
										</div>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
												<label class="control-label" for="nombre">Nombre:</label>
												</br>
											</div>
											<div class=" col-md-9">
                                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e(Auth::user()->name); ?>" readonly="readonly" >
												</br>
											</div>
										</div>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
												<label class="control-label" for="aula">Aula:</label>
												</br>
											</div>
											<div class=" col-md-9">
                      	<input type="text" class="form-control" id="aula" value="<?php echo e($incidencia -> aula); ?>" name="aula">
												</br>
											</div>
										</div>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
												<label class="control-label" for="equipo">Equipo:</label>
												</br>
											</div>
											<div class=" col-md-9">
                      	<input type="text" class="form-control" id="equipo" value="<?php echo e($incidencia -> equipo); ?>" name="equipo">
												</br>
											</div>
										</div>
</br>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
												<label class="control-label" for="estado">Estado:</label>
												</br>
											</div>
											<div class=" col-md-9">
												<input type="text" class="form-control" id="estado" value="<?php echo e($incidencia -> estado); ?>" name="estado" readonly="readonly">
												<select  name="estado" >
													 <option value="Abierto" >Abierto</option>
													 <option value="En Proceso" disabled>En Proceso</option>
													 <option value="Resuelta" >Resuelta</option>
													 <option value="Rechazada" disabled>Rechazada</option>
												</select>
                      </br>
											</div>
										</div>
                  </br>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
                        </br>
												<label class="control-label" for="codigo">Codigo Averia:</label>
												</br>
											</div>
                      </br>
											<div class=" col-md-9">
											<input type="text" class="form-control" id="codigo" value="<?php echo e($incidencia -> codigo); ?>" name="codigo" readonly="readonly">
                      <select name="codigo" >
													 <option value="1-No se enciende la CPU/ CPU ez da pizten">1-. No se enciende la CPU/ CPU ez da pizten</option>
													 <option value="2-No se enciende la pantalla/Pantaila ez da pizten">2-. No se enciende la pantalla/Pantaila ez da pizten</option>
													 <option value="3-No entra en mi sesión/ ezin sartu nere erabiltzailearekin">3-. No entra en mi sesión/ ezin sartu nere erabiltzailearekin</option>
													 <option value="4-No navega en Internet/ Internet ez dabil">4-. No navega en Internet/ Internet ez dabil</option>
													 <option value="5-No se oye el sonido/ Ez da aditzen">5-. No se oye el sonido/ Ez da aditzen</option>
													 <option value="6-No lee el DVD/CD">6-. No lee el DVD/CD</option>
													 <option value="7-Teclado roto/ Tekladu hondatuta">7-. Teclado roto/ Tekladu hondatuta</option>
													 <option value="8-No funciona el ratón/Xagua ez dabil">8-. No funciona el ratón/Xagua ez dabil</option>
													 <option value="9-Muy lento para entrar en la sesión/oso motel dijoa">9-. Muy lento para entrar en la sesión/oso motel dijoa</option>
													 <option value="10-(Otros) Especifica/Beste batzu">10-. (Otros) Especifica/Beste batzu</option>
												</select>
												</br>
											</div>
										</div>
										<div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
                        </br>
												<label class="control-label" for="descripcion">Descripción:</label>
												</br>
											</div>
											<div class=" col-md-7">
                        </br>
                      	<textarea class="form-control" rows="5" id="descripcion" name="descripcion" placeholder="<?php echo e($incidencia -> descripcion); ?>" readonly="readonly"><?php echo e($incidencia -> descripcion); ?></textarea>
											</div>
										</div>
                    <div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
                        </br>
												<label class="control-label" for="mas_info">Mas Información:</label>
												</br>
											</div>
											<div class=" col-md-7">
                        </br>
                      	<textarea class="form-control" rows="5" id="mas_info" name="mas_info" placeholder="Información adicional"><?php echo e($incidencia -> mas_info); ?> </textarea>

											</div>
										</div>
                    <?php if($incidencia -> comentarios_admin!=""): ?>
                    <div class="col-md-6 col-md-offset-1">
											<div class=" col-md-3">
                        </br>
												<label class="control-label" for="mas_info">Comentarios del Administrador:</label>
												</br>
											</div>
											<div class=" col-md-7">
                        </br>
                      	<textarea class="form-control" rows="5" id="mas_info" name="mas_info" placeholder="<?php echo e($incidencia -> comentarios_admin); ?>" readonly="readonly"><?php echo e($incidencia -> comentarios_admin); ?> </textarea>

											</div>
										</div>
                    <?php endif; ?>
										<div class="col-md-6 col-md-offset-1 text-center">
										<hr>
                    <div class="col-md-3 col-md-offset-2">
                      <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                    <div class="col-md-3 col-md-offset-2">
                      <a class="btn btn-primary"  href="<?php echo e(URL::previous()); ?>">Cancelar</a>
                    </div>

										</div>
									</div>
								</div>
								<?php if($errors->has('descripcion')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('descripcion')); ?></strong>
                  </span>
              	<?php endif; ?>
							  </form>

                </div>
                <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/liber/GestionIncidencias/resources/views/consultarIncidenciasProfesor.blade.php ENDPATH**/ ?>