<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Te has logueado como Administrador/a!
                    <br><br>
                    <center>
                        <div class="col-md-3 col-md-offset-2">
                            <a class="btn btn-info btn-lg btn-block" href="<?php echo e(route('verIncidenciaAdmin')); ?>">Ver</a>
                        </div>
                        <div class="col-md-3 col-md-offset-2">
                            <a class="btn btn-info btn-lg btn-block" href="<?php echo e(route('crearIncidenciaAdmin')); ?>">Crear</a>
                        </div>
                        <div class="col-md-3 col-md-offset-2">
                            <a class="btn btn-info btn-lg btn-block" href="<?php echo e(route('editAdminIncidencia')); ?>">Modificar</a>
                        </div>
                        
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/babace/Escritorio/GestionIncidencias/resources/views/homeAdministrador.blade.php ENDPATH**/ ?>