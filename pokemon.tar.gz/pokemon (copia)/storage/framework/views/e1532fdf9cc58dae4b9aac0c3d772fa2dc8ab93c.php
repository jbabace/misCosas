<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: black;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                width: 90%;
                margin: 0 auto;
            }
            .card-body{
                display: inline-block;
                background-color: #636b6f;
                margin: 5px;
                color: white;
            }
        </style>
    </head>
    <body>
        <div id="app">
            <example-component></example-component>
            
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html><?php /**PATH /home/babace/Escritorio/pokemon/resources/views/welcome.blade.php ENDPATH**/ ?>