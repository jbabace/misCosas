<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <style>
        html, body {
            background-color: black;
            color: white;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            width: 90%;
            margin: 0 auto;
        }
        .card-body{
            display: inline-block;
            background-color: #636b6f;
            margin: 5px;
        }
        .primcom{
            color: white;
            text-align: center;
            float: left;
        }
        
        table{
            border: 1px solid white;
        }
        td{
            border: 1px solid white;
            padding: 0 5px 0 5px;
        }


        .tabbed {
            overflow-x: hidden; /* so we could easily hide the radio inputs */
            margin: 32px 0;
            padding-bottom: 16px;
            border-bottom: 1px solid #ccc;
        }

        .tabbed [type="radio"] {
            /* hiding the inputs */
            display: none;
        }

        .tabs {
            display: flex;
            align-items: stretch;
            list-style: none;
            padding: 0;
            border-bottom: 1px solid #ccc;
        }
        .tab > label {
            display: block;
            margin-bottom: -1px;
            padding: 12px 15px;
            border: 1px solid #ccc;
            background: #eee;
            color: #666;
            font-size: 12px; 
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;	
            transition: all 0.3s;
        }
        .tab:hover label {
            border-top-color: #333;
            color: #333;
        }

        .tab-content {
            display: none;
            color: #777;
        }

        /* As we cannot replace the numbers with variables or calls to element properties, the number of this selector parts is our tab count limit */
        .tabbed [type="radio"]:nth-of-type(1):checked ~ .tabs .tab:nth-of-type(1) label,
        .tabbed [type="radio"]:nth-of-type(2):checked ~ .tabs .tab:nth-of-type(2) label,
        .tabbed [type="radio"]:nth-of-type(3):checked ~ .tabs .tab:nth-of-type(3) label,
        .tabbed [type="radio"]:nth-of-type(4):checked ~ .tabs .tab:nth-of-type(4) label,
        .tabbed [type="radio"]:nth-of-type(5):checked ~ .tabs .tab:nth-of-type(5) label,
        .tabbed [type="radio"]:nth-of-type(6):checked ~ .tabs .tab:nth-of-type(6) label,
        .tabbed [type="radio"]:nth-of-type(7):checked ~ .tabs .tab:nth-of-type(7) label {
            border-bottom-color: #fff;
            border-top-color: #B721FF;
            background: #fff;
            color: #222;
        }

        .tabbed [type="radio"]:nth-of-type(1):checked ~ .tab-content:nth-of-type(1),
        .tabbed [type="radio"]:nth-of-type(2):checked ~ .tab-content:nth-of-type(2),
        .tabbed [type="radio"]:nth-of-type(3):checked ~ .tab-content:nth-of-type(3),
        .tabbed [type="radio"]:nth-of-type(4):checked ~ .tab-content:nth-of-type(4),
        .tabbed [type="radio"]:nth-of-type(5):checked ~ .tab-content:nth-of-type(5),
        .tabbed [type="radio"]:nth-of-type(6):checked ~ .tab-content:nth-of-type(6),
        .tabbed [type="radio"]:nth-of-type(7):checked ~ .tab-content:nth-of-type(7) {
            display: block;
        }
        
    </style>
</head>
<body>
    <div id="app">
        <pokemon-component></pokemon-component>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

</body>
</html><?php /**PATH /home/babace/Escritorio/pokemon/resources/views/pokemon.blade.php ENDPATH**/ ?>