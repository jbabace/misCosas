<template>
    <div>
      <!--Hacer excepciones para Burmy, Giratina y Arceus-->
      <div v-for="pokemon in info.forms" :key="pokemon.name" class="primcom">
        <div v-if="id.length==1" class="card-body">
          <img v-bind:src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/00'+id+'.png'" >
        </div>
        <div v-if="id.length==2" class="card-body">
          <img v-bind:src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/0'+id+'.png'" >
        </div>
        <div v-if="id.length==3" class="card-body">
          <img v-bind:src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+id+'.png'" >
        </div>
        <h1 v-text="''+cleanStr(pokemon.name)+''" class="centrar"></h1>
      </div>
      <div v-for="pokemon in info.forms" :key="pokemon.information">
          <h2 v-text="''+cleanStr(pokemon.name)+'´s basic information'"></h2>
      </div>
        <br>
      <div class="segcom">

        <table border="1px solid white">
            <tr>
              <td>Pokédex number</td>
              <td>{{id}}</td>
            </tr>
            <tr>
              <td v-if="info.types[0].slot === 2">Types</td>
              <td v-else>Type</td>
              <td v-if="info.types[0].slot === 2">{{info.types[1].type.name}} {{info.types[0].type.name}}</td>
              <td v-else>{{info.types[0].type.name}}</td>
            </tr>
              <tr v-if="info.abilities.length==1">
                <td>Ability</td>
                <td><p v-text="''+ info.abilities[0].ability.name+''"></p></td>
              </tr>
            
              <tr v-else>
                <td>Ability</td>
                <td>
                  <p v-text="''+ info.abilities[1].ability.name+''">
                  <div v-if="info.abilities.length==3">
                    <span v-text="''+ info.abilities[2].ability.name+''"></span>
                  </div>
                  </p>
                </td>
              </tr>
              <tr v-if="info.abilities[0].is_hidden">
                <td>Hidden ability
                <td><p v-text="''+ info.abilities[0].ability.name+''"></p></td>
              </tr>
              <tr>
                <td>Egg groups</td>
                <td><p v-for=" grupo in info2.egg_groups" :key="grupo.tipo">{{grupo.name}}</p></td>
              </tr>
              <tr>
                <td>Weight</td>
                <td>{{(info.weight)/10}} kg</td>
              </tr>
              <tr>
                <td>Height</td>
                <td>{{(info.height)/10}} m</td>
              </tr>
        </table>
      </div>
      <div class="sprites">
        <h1>SPRITES</h1>
          <img :src="info.sprites.back_default"/>
          <img v-if="info.sprites.back_female != null" :src="info.sprites.back_female"/>
          <img :src="info.sprites.back_shiny"/>
          <img v-if="info.sprites.back_shiny_female != null" :src="info.sprites.back_shiny_female"/>
          <img :src="info.sprites.front_default"/>
          <img v-if="info.sprites.front_female != null" :src="info.sprites.front_female"/>
          <img :src="info.sprites.front_shiny"/>
          <img v-if="info.sprites.front_shiny_female != null" :src="info.sprites.front_shiny_female"/>
      </div>
      
      <p>{{info2.base_happiness}}</p>
      <p>{{info3.id}}</p>
      
      <div v-if="info3.id == 67">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <img v-for="evo in info3.chain.evolves_to" :key="evo.species" width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(evo.species.url)+'.png'">
      </div>
      <div v-else-if="info3.id == 10">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Level up + high happiness</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].item.name}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'_f2.png'"/>
      </div>  
      <div v-else-if="info3.id == 11">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'_f2.png'"/>
        <p>Evolves with ice stone </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div> 
      <div v-else-if="info3.id == 15">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].item.name}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'_f2.png'"/>
        <p>Evolves with ice stone </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div> 
      <div v-else-if="info3.id == 18">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].item.name}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolves_to[1].evolution_details[0].item.name}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[1].species.url)+'.png'"/>
      </div> 
      <div v-else-if="info3.id == 21">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'_f2.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div> 
      <div v-else-if="info3.id == 22">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'_f2.png'"/>
        <p>Level up + happiness </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div> 
      <div v-else-if="info3.id == 26">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].item.name}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
        <p>Trading poliwhirl with {{info3.chain.evolves_to[0].evolves_to[1].evolution_details[0].held_item.name}} equipped</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[1].species.url)+'.png'"/>
      </div> 
      <div v-else-if="info3.id == 31">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Trading</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'_f2.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
        <p>Trading</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'_f2.png'"/>
      </div>
      <div v-else-if="info3.id == 33">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Trading Slowpoke with {{info3.chain.evolves_to[1].evolution_details[0].held_item.name}} equipped</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[1].species.url)+'.png'"/>
        <p></p>
      </div>
      <div v-else-if="info3.id == 34">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Using {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Level up at an special magnet camp</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 45">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].item.name}} </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
      
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div> 
      <div v-else-if="info3.id == 46">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}/ In alola, level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} at night </p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/> 
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div>
      <div v-else-if="info3.id == 47">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <div v-for="evo in info3.chain.evolves_to" :key="evo.species">
          <p v-if="evo.evolution_details[0].relative_physical_stats===1">Level 20 + If Attack is higher than Defense</p> 
          <p v-else-if="evo.evolution_details[0].relative_physical_stats===-1">Level 20 + If Defense is higher than Attack</p> 
          <p v-else>Level 20 + If Attack and Defense are the same</p>
          <img :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(evo.species.url)+'.png'" width="15%" >
        </div> 
      </div>
      <div v-else-if="info3.id == 147">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Level up at an special magnet camp</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 178">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Level up with high beaty/ Trade with Prism Scale equipped (from the fifth generation onwards)</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 186">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <div v-for="evo in info3.chain.evolves_to" :key="evo.species">
          <p v-if="evo.evolution_details[0].min_level != null">Evolves at level {{evo.evolution_details[0].min_level}}</p> 
          <p v-else>Evolves with {{evo.evolution_details[0].item.name}} and has to be female </p>
          <img :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(evo.species.url)+'.png'" width="15%" >
        </div> 
      </div>
      <div v-else-if="info3.id == 188">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <div v-for="evo in info3.chain.evolves_to" :key="evo.species">
          <p>Evolves trading with {{evo.evolution_details[0].held_item.name}}</p> 
          <img :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(evo.species.url)+'.png'" width="15%" >
        </div> 
      </div>
      <div v-else-if="info3.id == 135">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[1].species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[1].evolves_to[0].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 213">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[1].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 380">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves leveling up at Mount Lanakila</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
      </div>
      <div v-else-if="info3.id == 383">
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>
        <p>Evolves at {{info3.chain.evolves_to[0].evolution_details[0].min_level}} at {{info3.chain.evolves_to[0].evolution_details[0].time_of_day}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>
        <p>Evolves at {{info3.chain.evolves_to[0].evolution_details[1].min_level}} at {{info3.chain.evolves_to[0].evolution_details[1].time_of_day}}</p>
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'_f2.png'"/>
      </div>    
      <div v-else>

        <!--Primer Pokemon de la cadena-->
        <img width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.species.url)+'.png'"/>

        <!--Forma de evolucionar del primer al segundo pokemon-->
        <div v-if="info3.chain.evolves_to[0] != null && info3.chain.evolves_to[0].evolution_details[0].trigger.name === 'level-up'">
          <p v-if="info3.chain.evolves_to[0].evolution_details[0].min_happiness != null">Level up + high happiness</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].time_of_day != '' && info3.chain.evolves_to[0].evolution_details[0].min_level !=null">Level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} at {{info3.chain.evolves_to[0].evolution_details[0].time_of_day}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].known_move != null">Level up + knowing {{info3.chain.evolves_to[0].evolution_details[0].known_move.name}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].held_item != null">Level up + {{info3.chain.evolves_to[0].evolution_details[0].held_item.name}} equipped</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].party_species != null">Level up + {{info3.chain.evolves_to[0].evolution_details[0].party_species.name}} in the team</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].party_type != null">Level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} + {{info3.chain.evolves_to[0].evolution_details[0].party_type.name}} type pokemon in the team</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].turn_upside_down">Level {{info3.chain.evolves_to[0].evolution_details[0].min_level}} with the 3DS upside down</p>
          <p v-else>Evolves at level {{info3.chain.evolves_to[0].evolution_details[0].min_level}}</p>
        </div>

        <div v-if="info3.chain.evolves_to[0] != null && info3.chain.evolves_to[0].evolution_details[0].trigger.name === 'use-item'">
          <p v-if="info3.chain.evolves_to[0].evolution_details[0].item !=null">Evolves with {{info3.chain.evolves_to[0].evolution_details[0].item.name}}</p>
        </div>

        <div v-if="info3.chain.evolves_to[0] != null && info3.chain.evolves_to[0].evolution_details[0].trigger.name === 'trade'">
          <p v-if="info3.chain.evolves_to[0].evolution_details[0].held_item != null">Trading with {{info3.chain.evolves_to[0].evolution_details[0].held_item.name}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolution_details[0].trade_species != null">Exchange for {{info3.chain.evolves_to[0].evolution_details[0].trade_species.name}}</p>
          <p v-else>Trade</p>
        </div>
        <!--Hacer uno para Shedinja-->

        <!--Segundo Pokemon de la cadena-->
        <img v-if="info3.chain.evolves_to[0] != undefined" width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].species.url)+'.png'"/>

        <!--Forma de evolucionar del segundo al tercer pokemon-->
        <div v-if="info3.chain.evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].trigger.name === 'level-up'">
          <p v-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_happiness != null">Level up + high happiness</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].time_of_day != '' && info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_level !=null">Level {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_level}} at {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].time_of_day}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].known_move != null">Level up + knowing {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].known_move.name}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].held_item != null">Level up + {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].held_item.name}} equipped</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].party_species != null">Level up + {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].party_species.name}} in the team</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].party_type != null">Level {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_level}} + {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].party_type.name}} type pokemon in the team</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].turn_upside_down">Level {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_level}} with the 3DS upside down</p>
          <p v-else>Evolves at level {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].min_level}}</p>
        </div>

        <div v-if="info3.chain.evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].trigger.name === 'use-item'">
          <p v-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].item !=null">Evolves with {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].item.name}}</p>
        </div>

        <div v-if="info3.chain.evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].trigger.name === 'trade'">
          <p v-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].held_item != null">Trading with {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].held_item.name}}</p>
          <p v-else-if="info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].trade_species != null">Exchange for {{info3.chain.evolves_to[0].evolves_to[0].evolution_details[0].trade_species.name}}</p>
          <p v-else>Trade</p>
        </div>

        <!--Tercer Pokemon de la cadena-->
        <img v-if="info3.chain.evolves_to[0] != undefined && info3.chain.evolves_to[0].evolves_to[0] != undefined"  width="15%" :src="'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+idExt(info3.chain.evolves_to[0].evolves_to[0].species.url)+'.png'"/>
      </div>

      <div class="stats">
        <table>
          <tr>
            <th>Stat</th>
            <th>Value</th>
          </tr>
          <tr>
            <td>{{info.stats[5].stat.name}}</td>
            <td>{{info.stats[5].base_stat}}</td>
          </tr>
          <tr>
            <td>{{info.stats[4].stat.name}}</td>
            <td>{{info.stats[4].base_stat}}</td>
          </tr>
          <tr>
            <td>{{info.stats[3].stat.name}}</td>
            <td>{{info.stats[3].base_stat}}</td>
          </tr>
          <tr>
            <td>{{info.stats[2].stat.name}}</td>
            <td>{{info.stats[2].base_stat}}</td>
          </tr>
          <tr>
            <td>{{info.stats[1].stat.name}}</td>
            <td>{{info.stats[1].base_stat}}</td>
          </tr>
          <tr>
            <td>{{info.stats[0].stat.name}}</td>
            <td>{{info.stats[0].base_stat}}</td>
          </tr>
        </table>
      </div>

      <!-- Necesario llamar a este metodo -->
      <div>{{comprobarGeneracion()}}</div>
      <div>{{movNivelDef(info)}}</div>
      <div>{{movMTDef(info)}}</div>

      <div>{{otrosMov}}</div>

      <h2>Movimientos por nivel</h2>

      <div class="tabbed">
        <input type="radio" id="tab1" name="css-tabs" checked>
        <input type="radio" id="tab2" name="css-tabs">
        <input type="radio" id="tab3" name="css-tabs">
        <input type="radio" id="tab4" name="css-tabs">
        <input type="radio" id="tab5" name="css-tabs">
        <input type="radio" id="tab6" name="css-tabs">
        <input type="radio" id="tab7" name="css-tabs">
        
        <ul class="tabs">
          <li class="tab"><label for="tab1">Generacion 1</label></li>
          <li class="tab"><label for="tab2">Generacion 2</label></li>
          <li class="tab"><label for="tab3">Generacion 3</label></li>
          <li class="tab"><label for="tab4">Generacion 4</label></li>
          <li class="tab"><label for="tab5">Generacion 5</label></li>
          <li class="tab"><label for="tab6">Generacion 6</label></li>
          <li class="tab"><label for="tab7">Generacion 7</label></li>
        </ul>

        <template v-for="gen in 7">

        <div class="tab-content">
          <div v-if="existeGen[gen-1].existe == false">
            <p>{{info.name}} no se encuentra en la {{gen}} generacion</p>
          </div>
          <div v-else>
          <table>
            <tr>
              <th>Nivel</th>
              <th>Movimiento</th>
              <th>Juego</th>
            </tr>
            <template v-for="j in listaNivel">
            <tr v-if="j.generacion == gen">
              <td>{{j.nivel}}</td>
              <td>{{j.nombre}}</td>
              <td>{{j.juego}}</td>
            </tr>
            </template>
          </table>
          </div>
        </div>

        </template>
      </div>

      <h2>Movimientos por MT/MO</h2>

      <div class="tabbed">
        <input type="radio" id="tab21" name="css-tabs2" checked>
        <input type="radio" id="tab22" name="css-tabs2">
        <input type="radio" id="tab23" name="css-tabs2">
        <input type="radio" id="tab24" name="css-tabs2">
        <input type="radio" id="tab25" name="css-tabs2">
        <input type="radio" id="tab26" name="css-tabs2">
        <input type="radio" id="tab27" name="css-tabs2">

        <ul class="tabs">
          <li class="tab"><label for="tab21">Generacion 1</label></li>
          <li class="tab"><label for="tab22">Generacion 2</label></li>
          <li class="tab"><label for="tab23">Generacion 3</label></li>
          <li class="tab"><label for="tab24">Generacion 4</label></li>
          <li class="tab"><label for="tab25">Generacion 5</label></li>
          <li class="tab"><label for="tab26">Generacion 6</label></li>
          <li class="tab"><label for="tab27">Generacion 7</label></li>
        </ul>

        <template v-for="gen in 7">

        <div class="tab-content">

          <template v-if="existeGen[gen-1].existe == false">
            <p>{{info.name}} no se encuentra en la {{gen}} generacion</p>
          </template>

          <template v-else-if="otrosMov[gen-1].maquina == false">
            <p>{{info.name}} no aprende movimientos por MT/MO en la {{gen}} generacion</p>
          </template>

          <template v-else>
          <table>
            <tr>
              <th>Movimiento</th>
              <th>Juego</th>
            </tr>
            <template v-for="j in listaOtros">
              <tr v-if="j.metodo == 'machine' && j.generacion == gen">
                <td>{{j.nombre}}</td>
                <td>{{j.juego}}</td>
              </tr>
            </template>
          </table>
          </template>
        </div>

        </template>
      </div>

      <h2>Movimientos por tutor</h2>

      <div class="tabbed">
        <input type="radio" id="tab31" name="css-tabs3" checked>
        <input type="radio" id="tab32" name="css-tabs3">
        <input type="radio" id="tab33" name="css-tabs3">
        <input type="radio" id="tab34" name="css-tabs3">
        <input type="radio" id="tab35" name="css-tabs3">
        <input type="radio" id="tab36" name="css-tabs3">
        <input type="radio" id="tab37" name="css-tabs3">

        <ul class="tabs">
          <li class="tab"><label for="tab31">Generacion 1</label></li>
          <li class="tab"><label for="tab32">Generacion 2</label></li>
          <li class="tab"><label for="tab33">Generacion 3</label></li>
          <li class="tab"><label for="tab34">Generacion 4</label></li>
          <li class="tab"><label for="tab35">Generacion 5</label></li>
          <li class="tab"><label for="tab36">Generacion 6</label></li>
          <li class="tab"><label for="tab37">Generacion 7</label></li>
        </ul>

        <template v-for="gen in 7">

        <div class="tab-content">

          <template v-if="existeGen[gen-1].existe == false">
            <p>{{info.name}} no se encuentra en la {{gen}} generacion</p>
          </template>

          <template v-else-if="otrosMov[gen-1].tutor == false">
            <p>{{info.name}} no aprende movimientos por tutor en la {{gen}} generacion</p>
          </template>

          <template v-else>
          <table>
            <tr>
              <th>Movimiento</th>
              <th>Juego</th>
            </tr>
            <template v-for="j in listaOtros">
              <tr v-if="j.metodo == 'tutor' && j.generacion == gen">
                <td>{{j.nombre}}</td>
                <td>{{j.juego}}</td>
              </tr>
            </template>
          </table>
          </template>
        </div>

        </template>
      </div>

      <h2>Movimientos huevo</h2>

      <div class="tabbed">
        <input type="radio" id="tab41" name="css-tabs4" checked>
        <input type="radio" id="tab42" name="css-tabs4">
        <input type="radio" id="tab43" name="css-tabs4">
        <input type="radio" id="tab44" name="css-tabs4">
        <input type="radio" id="tab45" name="css-tabs4">
        <input type="radio" id="tab46" name="css-tabs4">
        <input type="radio" id="tab47" name="css-tabs4">

        <ul class="tabs">
          <li class="tab"><label for="tab41">Generacion 1</label></li>
          <li class="tab"><label for="tab42">Generacion 2</label></li>
          <li class="tab"><label for="tab43">Generacion 3</label></li>
          <li class="tab"><label for="tab44">Generacion 4</label></li>
          <li class="tab"><label for="tab45">Generacion 5</label></li>
          <li class="tab"><label for="tab46">Generacion 6</label></li>
          <li class="tab"><label for="tab47">Generacion 7</label></li>
        </ul>

        <template v-for="gen in 7">

        <div class="tab-content">

          <template v-if="gen == 1">
            <p>Los movimientos huevo no existen en la {{gen}} generacion</p>
          </template>

          <template v-else-if="existeGen[gen-1].existe == false">
            <p>{{info.name}} no se encuentra en la {{gen}} generacion</p>
          </template>

          <template v-else-if="otrosMov[gen-1].huevo == false">
            <p>{{info.name}} no aprende movimientos huevo en la {{gen}} generacion</p>
          </template>

          <template v-else>
          <table>
            <tr>
              <th>Movimiento</th>
              <th>Juego</th>
            </tr>
            <template v-for="j in listaOtros">
              <tr v-if="j.metodo == 'egg' && j.generacion == gen">
                <td>{{j.nombre}}</td>
                <td>{{j.juego}}</td>
              </tr>
            </template>
          </table>
          </template>
        </div>

        </template>
      </div>

    <br><br>

    </div>

    

    
</template>
<script>
import axios from 'axios';


export default {
    data () {
        return {
          info: null,
          id: window.location.pathname.split('/')[2],
          aux: 2,
          info2: null,
          info3: null,
          
          nombreMov: "",
          nivelMov: "",
          metodoMov: "",
          juegoMov: "",
          genMov: 0,
          urlMov: "",
          juegoPer: "",

          listaNivel: null,
          listaOtros: null,

          existeGen: [{existe: false},{existe: false},{existe: false},{existe: false},{existe: false},{existe: false},{existe: false}],

          otrosMov: [
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
            {maquina: false, tutor: false, huevo: false},
          ]

        }
      },
      mounted () {
        var id= window.location.pathname.split('/')[2];

        axios
          .get(`https://pokeapi.co/api/v2/pokemon/${id}`)
          .then(response => {this.info = response.data
            axios.get(`https://pokeapi.co/api/v2/pokemon-species/${id}`)
            .then(response => {this.info2 = response.data
              axios.get(response.data.evolution_chain.url)
              .then(response => (this.info3 =response.data))
            })
          });
          console.log(response);

      }, methods:{

        subStr(string) {
          return string.substring(34,string.length-1);
        },

        cleanStr(string){ 
          string = string.toUpperCase(); 
          string = string.replace("-", " ");
          return string;
        },

        idExt(string){
          string=string.split('/')[6];
          if(string.length==1){
            string='00'+string;
          }else if(string.length==2){
            string='0'+string;
          }
          return string;
        },

        
        comprobarGeneracion(){

          var i = 0;
          var count = 0;

          while (i != this.info.moves.length && count < 7){
            for (let j = 0; j < this.info.moves[i].version_group_details.length; j++){
              this.juegoMov = this.info.moves[i].version_group_details[j].version_group.name;
              if (this.juegoMov == "ultra-sun-ultra-moon" || this.juegoMov == "sun-moon"){
                this.existeGen[6] = {existe: true};
              } else if (this.juegoMov == "omega-ruby-alpha-sapphire" || this.juegoMov == "x-y") {
                this.existeGen[5].existe = true;
              } else if (this.juegoMov == "black-2-white-2" || this.juegoMov == "black-white") {
                this.existeGen[4].existe = true;
              } else if (this.juegoMov == "heartgold-soulsilver" || this.juegoMov == "platinum" || this.juegoMov == "diamond-pearl") {
                this.existeGen[3].existe = true;
              } else if (this.juegoMov == "firered-leafgreen" || this.juegoMov == "emerald" || this.juegoMov == "ruby-sapphire") {
                this.existeGen[2].existe = true;
              } else if (this.juegoMov == "crystal" || this.juegoMov == "gold-silver") {
                this.existeGen[1].existe = true;
              } else if (this.juegoMov == "yellow" || this.juegoMov == "red-blue") {
                this.existeGen[0].existe = true;
              }

              this.juegoMov = "";
            }

            count = 0;

            for(let k = 0; k < this.existeGen[k].length; k++){
              if (this.existeGen[k].existe == true){
                count = count + 1;
              }
            }

            i = i +1;
          }
          
        },

        movNivelDef(informacion){
          var mov;
          var lista = [];
          var listaCorregida = [];
          var listaFinal = [];
          var ordenado = false;
          var string = "";

          for (let i = 0; i < informacion.moves.length; i++){
            this.nombreMov = informacion.moves[i].move.name;
            for (let j = 0; j < informacion.moves[i].version_group_details.length; j++){
              this.nivelMov = informacion.moves[i].version_group_details[j].level_learned_at;
              this.juegoMov = informacion.moves[i].version_group_details[j].version_group.name;
              if (this.nivelMov != 0){
                if (this.juegoMov == "ultra-sun-ultra-moon" || this.juegoMov == "sun-moon"){
                  this.genMov = 7;
                  if(this.juegoMov == "ultra-sun-ultra-moon"){
                    this.juegoPer = "US / UM";
                  }else{
                    this.juegoPer = "S / M"
                  }
                } else if (this.juegoMov == "omega-ruby-alpha-sapphire" || this.juegoMov == "x-y") {
                  this.genMov = 6;
                  if(this.juegoMov == "omega-ruby-alpha-sapphire"){
                    this.juegoPer = "OR / AS";
                  }else{
                    this.juegoPer = "X / Y"
                  }
                } else if (this.juegoMov == "black-2-white-2" || this.juegoMov == "black-white") {
                  this.genMov = 5;
                  if(this.juegoMov == "black-2-white-2"){
                    this.juegoPer = "B2 / W2";
                  }else{
                    this.juegoPer = "B / W"
                  }
                } else if (this.juegoMov == "heartgold-soulsilver" || this.juegoMov == "platinum" || this.juegoMov == "diamond-pearl") {
                  this.genMov = 4;
                  if(this.juegoMov == "heartgold-soulsilver"){
                    this.juegoPer = "HG / SS";
                  }else if (this.juegoMov == "platinum"){
                    this.juegoPer = "Pl"
                  }else{
                    this.juegoPer = "D / P"
                  }
                } else if (this.juegoMov == "firered-leafgreen" || this.juegoMov == "emerald" || this.juegoMov == "ruby-sapphire") {
                  this.genMov = 3;
                  if(this.juegoMov == "firered-leafgreen"){
                    this.juegoPer = "FR / LG";
                  }else if (this.juegoMov == "emerald"){
                    this.juegoPer = "Em"
                  }else{
                    this.juegoPer = "R / S"
                  }
                } else if (this.juegoMov == "crystal" || this.juegoMov == "gold-silver") {
                  this.genMov = 2;
                  if(this.juegoMov == "crystal"){
                    this.juegoPer = "Cr";
                  }else{
                    this.juegoPer = "G / S"
                  }
                } else if (this.juegoMov == "yellow" || this.juegoMov == "red-blue") {
                  this.genMov = 1;
                  if(this.juegoMov == "yellow"){
                    this.juegoPer = "Ye";
                  }else{
                    this.juegoPer = "R / B"
                  }
                } else {
                  this.genMov = 0;
                }
                if(this.genMov != 0){
                  let mov = {nivel: this.nivelMov, nombre: this.nombreMov, generacion: this.genMov, juego: this.juegoPer};
                  lista.push(mov);
                }
              }
            }
          }
          while(!ordenado){
            ordenado = true;
            for (let i = 0;i < lista.length-1;i++){
              if (lista[i].generacion > lista[i+1].generacion){
                let mov = lista[i];
                lista[i] = lista[i+1];
                lista[i+1] = mov;
                ordenado = false;
              }
            }
          }
          ordenado = false;
          while(!ordenado){
            ordenado = true;
            for (let i = 0;i < lista.length-1;i++){
              if (lista[i].nivel > lista[i+1].nivel){
                let mov = lista[i];
                lista[i] = lista[i+1];
                lista[i+1] = mov;
                ordenado = false;
              }
            }
          }
          for (let i = 0;i < lista.length-1;i++){
            if (lista[i].nombre != lista[i+1].nombre){
              listaCorregida.push(lista[i]);
            }
            else if (lista[i].generacion != lista[i+1].generacion){
              listaCorregida.push(lista[i]);
            }
            else{
              lista[i+1].juego = lista[i+1].juego + " / " + lista[i].juego;
            }

            if (i+1 == lista.length-1){
              listaCorregida.push(lista[i]);
            }
          }

          this.listaNivel = listaCorregida;
        },

        movMTDef(informacion){
          var mov;
          var lista = [];
          var listaCorregida = [];
          var listaFinal = [];
          var ordenado = false;
          var string = "";
          for (let i = 0; i < informacion.moves.length; i++){
            this.nombreMov = informacion.moves[i].move.name;
            for (let j = 0; j < informacion.moves[i].version_group_details.length; j++){
              this.nivelMov = informacion.moves[i].version_group_details[j].level_learned_at;
              this.juegoMov = informacion.moves[i].version_group_details[j].version_group.name;
              if (this.nivelMov == 0){
                this.metodoMov = informacion.moves[i].version_group_details[j].move_learn_method.name;
                if (this.juegoMov == "ultra-sun-ultra-moon" || this.juegoMov == "sun-moon"){
                  this.genMov = 7;
                  if(this.juegoMov == "ultra-sun-ultra-moon"){
                    this.juegoPer = "US / UM";
                  }else{
                    this.juegoPer = "S / M"
                  }
                } else if (this.juegoMov == "omega-ruby-alpha-sapphire" || this.juegoMov == "x-y") {
                  this.genMov = 6;
                  if(this.juegoMov == "omega-ruby-alpha-sapphire"){
                    this.juegoPer = "OR / AS";
                  }else{
                    this.juegoPer = "X / Y"
                  }
                } else if (this.juegoMov == "black-2-white-2" || this.juegoMov == "black-white") {
                  this.genMov = 5;
                  if(this.juegoMov == "black-2-white-2"){
                    this.juegoPer = "B2 / W2";
                  }else{
                    this.juegoPer = "B / W"
                  }
                } else if (this.juegoMov == "heartgold-soulsilver" || this.juegoMov == "platinum" || this.juegoMov == "diamond-pearl") {
                  this.genMov = 4;
                  if(this.juegoMov == "heartgold-soulsilver"){
                    this.juegoPer = "HG / SS";
                  }else if (this.juegoMov == "platinum"){
                    this.juegoPer = "Pl"
                  }else{
                    this.juegoPer = "D / P"
                  }
                } else if (this.juegoMov == "firered-leafgreen" || this.juegoMov == "emerald" || this.juegoMov == "ruby-sapphire") {
                  this.genMov = 3;
                  if(this.juegoMov == "firered-leafgreen"){
                    this.juegoPer = "FR / LG";
                  }else if (this.juegoMov == "emerald"){
                    this.juegoPer = "Em"
                  }else{
                    this.juegoPer = "R / S"
                  }
                } else if (this.juegoMov == "crystal" || this.juegoMov == "gold-silver") {
                  this.genMov = 2;
                  if(this.juegoMov == "crystal"){
                    this.juegoPer = "Cr";
                  }else{
                    this.juegoPer = "G / S"
                  }
                } else if (this.juegoMov == "yellow" || this.juegoMov == "red-blue") {
                  this.genMov = 1;
                  if(this.juegoMov == "yellow"){
                    this.juegoPer = "Ye";
                  }else{
                    this.juegoPer = "R / B"
                  }
                } else {
                  this.genMov = 0;
                }

                if(this.genMov != 0){
                  let generacion = this.genMov - 1;
                  if(this.metodoMov == "machine"){
                    this.otrosMov[generacion].maquina = true;
                  }else if(this.metodoMov == "tutor"){
                    this.otrosMov[generacion].tutor = true;
                  }else if(this.metodoMov == "egg"){
                    this.otrosMov[generacion].huevo = true;
                  }
                }
                

                let mov = {metodo: this.metodoMov, nombre: this.nombreMov, generacion: this.genMov, juego: this.juegoPer};
                lista.push(mov);
              }
              this.nivelMov = "";
              this.metodoMov = "";
              this.juegoMov = "";
              this.genMov = 0;
            }
            this.nombreMov = "";
          }

          while(!ordenado){
            ordenado = true;
            for (let i = 0;i < lista.length-1;i++){
              if (lista[i].generacion > lista[i+1].generacion){
                let mov = lista[i];
                lista[i] = lista[i+1];
                lista[i+1] = mov;
                ordenado = false;
              }
            }
          }

          for (let i = 0;i < lista.length-1;i++){
            if (lista[i].nombre != lista[i+1].nombre){
              listaCorregida.push(lista[i]);
            }
            else if (lista[i].generacion != lista[i+1].generacion){
              listaCorregida.push(lista[i]);
            }
            else{
              lista[i+1].juego = lista[i+1].juego + " / " + lista[i].juego;
            }

            if (i == lista.length-1){
              listaCorregida.push(lista[i]);
            }
          }

          this.listaOtros = listaCorregida;
        },
      }
}
</script>