<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Example Component</div>

                    <div>
                        <div v-for="pokemon in info.results" :key="pokemon.name" class="card-body">
                            
                            <img v-bind:src="'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/'+subStr(pokemon.url)+'.png'" v-bind:alt="''+pokemon.name+''">
                            <center><a v-bind:href="'/pokemon/'+ subStr(pokemon.url) +''"><h5 v-text="''+cleanStr(pokemon.name)+''"></h5></a></center>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
    const id = 0;
    export default {
        data () {
        return {
          info: null,
        }
      },
      mounted () {
        axios
          .get('https://pokeapi.co/api/v2/pokemon/?limit=964')
          .then(response => (this.info = response.data))
          console.log(response)
      }, methods:{
            subStr(string) {
    	        return string.substring(34,string.length-1);
        },
            cleanStr(string){
                
                string = string.toUpperCase(); 
                string = string.replace("-", " ");
                return string;
            }
      }
      
    }
</script>